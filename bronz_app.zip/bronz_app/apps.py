from django.apps import AppConfig

class BronzAppConfig(AppConfig):
    name = 'bronz_app'

    
