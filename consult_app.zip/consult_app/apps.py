from django.apps import AppConfig


class ConsultasAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'consult_app'
